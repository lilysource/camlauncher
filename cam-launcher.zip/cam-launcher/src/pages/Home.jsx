import { NavLink } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'
import Footer from '../components/Footer.jsx'

const features = [
  {
    title: 'Blazing Fast',
    desc: 'Optimized boot sequence gets you from click to game in seconds, not minutes.',
    icon: (
      <path d="M13 2L4.5 13.5H11L10 22L19.5 10H13L13 2Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
    ),
  },
  {
    title: 'Secure by Design',
    desc: 'Every release is signed and checksummed so what you download is what you get.',
    icon: (
      <path d="M12 2L4 5V11C4 16.5 7.4 20.7 12 22C16.6 20.7 20 16.5 20 11V5L12 2Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
    ),
  },
  {
    title: 'One-Click Updates',
    desc: 'The launcher keeps itself current in the background — no more manual patching.',
    icon: (
      <path d="M4 12C4 7.6 7.6 4 12 4C15 4 17.6 5.7 19 8.2M20 12C20 16.4 16.4 20 12 20C9 20 6.4 18.3 5 15.8M19 4V8.2H14.8M5 20V15.8H9.2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    ),
  },
  {
    title: 'Lightweight Footprint',
    desc: 'A minimal install that stays out of the way of your CPU, RAM, and storage.',
    icon: (
      <path d="M4 7L12 3L20 7V17L12 21L4 17V7Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
    ),
  },
  {
    title: 'Clean Interface',
    desc: 'No clutter, no ads — just your library, front and center every time you open it.',
    icon: (
      <path d="M4 5H20V19H4V5Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
    ),
  },
  {
    title: 'Built for Everyone',
    desc: 'Full Khmer language support alongside English, with more locales on the way.',
    icon: (
      <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z" stroke="currentColor" strokeWidth="1.6" />
    ),
  },
]

export default function Home() {
  return (
    <div className="min-h-screen bg-void-950">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden px-5 pb-24 pt-20 md:pt-28">
        <div className="grid-bg pointer-events-none absolute inset-0 -top-20 h-[600px]" />
        <div className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-cam-500/20 blur-[120px]" />

        <div className="relative mx-auto max-w-4xl text-center">
          <span className="eyebrow inline-flex items-center gap-2 rounded-full border border-cam-500/25 bg-white/[0.03] px-4 py-1.5 animate-fade-up">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cam-400 opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cam-400" />
            </span>
            Version 2.0 is live
          </span>

          <h1 className="mt-6 animate-fade-up font-display text-5xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl" style={{ animationDelay: '80ms' }}>
            Cam <span className="bg-gradient-to-r from-cam-400 to-cam-600 bg-clip-text text-transparent">Launcher</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl animate-fade-up text-lg text-slate-400 sm:text-xl" style={{ animationDelay: '160ms' }}>
            Fast, Secure, and Easy Launcher
          </p>

          <div className="mt-10 flex animate-fade-up flex-col items-center justify-center gap-4 sm:flex-row" style={{ animationDelay: '240ms' }}>
            <NavLink to="/download" className="glow-btn w-full sm:w-auto">
              <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5">
                <path d="M12 3V15M12 15L7 10M12 15L17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M4 17V19C4 20.1046 4.89543 21 6 21H18C19.1046 21 20 20.1046 20 19V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              Download Now
            </NavLink>
            <NavLink to="/changelog" className="glow-btn-outline w-full sm:w-auto">
              View Changelog
            </NavLink>
          </div>
        </div>

        {/* Floating preview panel */}
        <div className="relative mx-auto mt-20 max-w-3xl animate-float">
          <div className="glass-card mx-auto flex max-w-2xl items-center gap-4 p-4 shadow-glow">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cam-500 to-cam-700 shadow-glow">
              <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8 text-white">
                <path d="M5 19L12 4L19 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M8.5 13H15.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
            <div className="flex-1 text-left">
              <div className="h-2.5 w-32 rounded-full bg-white/10" />
              <div className="mt-2 h-2 w-48 rounded-full bg-white/5" />
            </div>
            <span className="hidden rounded-lg bg-emerald-500/10 px-3 py-1.5 font-display text-xs font-semibold text-emerald-400 ring-1 ring-emerald-500/20 sm:block">
              Ready to launch
            </span>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="relative border-t border-cam-500/10 bg-void-900/40 px-5 py-24">
        <div className="mx-auto max-w-6xl">
          <div className="mx-auto max-w-xl text-center">
            <span className="eyebrow">Why Cam Launcher</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-white sm:text-4xl">
              Everything you need, nothing you don't
            </h2>
          </div>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f, i) => (
              <div
                key={f.title}
                className="glass-card animate-fade-up p-6 transition-all duration-300 hover:-translate-y-1 hover:border-cam-500/40"
                style={{ animationDelay: `${i * 70}ms` }}
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-cam-500/10 text-cam-400 ring-1 ring-cam-500/20">
                  <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5">
                    {f.icon}
                  </svg>
                </div>
                <h3 className="mt-4 font-display text-lg font-bold text-white">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden px-5 py-24 text-center">
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-[300px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cam-500/15 blur-[100px]" />
        <div className="relative mx-auto max-w-2xl">
          <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">
            Ready to launch faster?
          </h2>
          <p className="mt-4 text-slate-400">
            Join players already running Cam Launcher on Windows.
          </p>
          <NavLink to="/download" className="glow-btn mt-8 inline-flex">
            Download Now
          </NavLink>
        </div>
      </section>

      <Footer />
    </div>
  )
}
