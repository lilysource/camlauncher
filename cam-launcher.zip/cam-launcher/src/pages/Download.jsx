import { useMemo, useState } from 'react'
import Navbar from '../components/Navbar.jsx'
import Footer from '../components/Footer.jsx'
import VersionCard from '../components/VersionCard.jsx'
import { getDownloads } from '../data/downloads.js'

export default function Download() {
  const [query, setQuery] = useState('')
  const downloads = useMemo(() => getDownloads(), [])

  const filtered = downloads
    .filter((d) => d.version.toLowerCase().includes(query.trim().toLowerCase()))
    .sort((a, b) => (a.isLatest === b.isLatest ? 0 : a.isLatest ? -1 : 1))

  const latest = downloads.find((d) => d.isLatest)

  return (
    <div className="min-h-screen bg-void-950">
      <Navbar />

      <section className="relative overflow-hidden px-5 pb-10 pt-16">
        <div className="grid-bg pointer-events-none absolute inset-0 -top-20 h-[400px]" />
        <div className="relative mx-auto max-w-3xl text-center">
          <span className="eyebrow">Downloads</span>
          <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
            Get Cam Launcher
          </h1>
          <p className="mt-4 text-slate-400">
            Choose a version below. We recommend always running the latest release for the best performance and security.
          </p>

          {latest && (
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-cam-500/25 bg-cam-500/10 px-4 py-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cam-400 opacity-75" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cam-400" />
              </span>
              <span className="font-display text-xs font-semibold uppercase tracking-wider text-cam-400">
                Latest: v{latest.version}
              </span>
            </div>
          )}
        </div>
      </section>

      <section className="px-5 pb-24">
        <div className="mx-auto max-w-3xl">
          <div className="relative mb-8">
            <svg viewBox="0 0 24 24" fill="none" className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500">
              <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.6" />
              <path d="M21 21L16.5 16.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by version (e.g. 2.0.0)"
              className="w-full rounded-xl border border-cam-500/20 bg-white/[0.03] py-3.5 pl-12 pr-4 font-body text-white placeholder-slate-500 backdrop-blur-xl transition-colors duration-200 focus:border-cam-400 focus:outline-none"
            />
          </div>

          <div className="flex flex-col gap-4">
            {filtered.length > 0 ? (
              filtered.map((d) => <VersionCard key={d.id} {...d} />)
            ) : (
              <div className="glass-card p-10 text-center text-slate-400">
                No versions match “{query}”.
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
