import { NavLink } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col bg-void-950">
      <Navbar />
      <div className="flex flex-1 flex-col items-center justify-center px-5 text-center">
        <span className="font-display text-7xl font-bold text-cam-500/40">404</span>
        <h1 className="mt-4 font-display text-2xl font-bold text-white">Page not found</h1>
        <p className="mt-2 text-slate-400">The page you're looking for doesn't exist.</p>
        <NavLink to="/" className="glow-btn mt-8">Back to Home</NavLink>
      </div>
    </div>
  )
}
