import { useMemo } from 'react'
import Navbar from '../components/Navbar.jsx'
import Footer from '../components/Footer.jsx'
import { getChangelog } from '../data/changelog.js'

export default function Changelog() {
  const changelog = useMemo(() => getChangelog(), [])

  return (
    <div className="min-h-screen bg-void-950">
      <Navbar />

      <section className="relative overflow-hidden px-5 pb-10 pt-16">
        <div className="grid-bg pointer-events-none absolute inset-0 -top-20 h-[400px]" />
        <div className="relative mx-auto max-w-3xl text-center">
          <span className="eyebrow">Changelog</span>
          <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
            Update History
          </h1>
          <p className="mt-4 text-slate-400">
            Every improvement, fix, and feature we've shipped — in one place.
          </p>
        </div>
      </section>

      <section className="px-5 pb-24">
        <div className="mx-auto max-w-2xl">
          <ol className="relative border-l border-cam-500/20 pl-8">
            {changelog.map((entry, i) => (
              <li key={entry.id} className="relative animate-fade-up pb-12 last:pb-0" style={{ animationDelay: `${i * 90}ms` }}>
                <span className="absolute -left-[38px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-void-950 ring-2 ring-cam-500">
                  <span className="h-1.5 w-1.5 rounded-full bg-cam-400" />
                </span>

                <div className="glass-card p-6">
                  <div className="flex flex-wrap items-center gap-3">
                    <h2 className="font-display text-xl font-bold text-white">
                      Version {entry.version}
                    </h2>
                    {i === 0 && (
                      <span className="rounded-full bg-cam-500/15 px-2.5 py-0.5 font-display text-[11px] font-bold uppercase tracking-wider text-cam-400 ring-1 ring-cam-500/30">
                        Latest
                      </span>
                    )}
                    {entry.date && (
                      <span className="text-xs text-slate-500">
                        {new Date(entry.date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </span>
                    )}
                  </div>

                  <ul className="mt-4 space-y-2.5">
                    {entry.items.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-300">
                        <svg viewBox="0 0 24 24" fill="none" className="mt-0.5 h-4 w-4 shrink-0 text-cam-400">
                          <path d="M5 13L9 17L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <Footer />
    </div>
  )
}
