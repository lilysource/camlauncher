import { useState } from 'react'
import { Navigate, useLocation, useNavigate, NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'

export default function Login() {
  const { login, isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  if (isAuthenticated) {
    const dest = location.state?.from?.pathname || '/admin'
    return <Navigate to={dest} replace />
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setError('')
    setSubmitting(true)

    setTimeout(() => {
      const result = login(username.trim(), password)
      setSubmitting(false)
      if (result.success) {
        navigate('/admin', { replace: true })
      } else {
        setError(result.error)
      }
    }, 350)
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-void-950 px-5">
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[400px] w-[400px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cam-500/15 blur-[120px]" />

      <div className="relative w-full max-w-sm">
        <NavLink to="/" className="mb-8 flex items-center justify-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cam-500 to-cam-700 shadow-glow">
            <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-white">
              <path d="M5 19L12 4L19 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M8.5 13H15.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </span>
          <span className="font-display text-xl font-bold text-white">Cam Launcher</span>
        </NavLink>

        <div className="glass-card p-8 shadow-glow">
          <h1 className="font-display text-2xl font-bold text-white">Admin Sign In</h1>
          <p className="mt-1.5 text-sm text-slate-400">Restricted area. Authorized personnel only.</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            <div>
              <label htmlFor="username" className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
                Username
              </label>
              <input
                id="username"
                type="text"
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full rounded-xl border border-cam-500/20 bg-white/[0.03] px-4 py-3 text-white placeholder-slate-600 transition-colors duration-200 focus:border-cam-400 focus:outline-none"
                placeholder="Enter username"
              />
            </div>

            <div>
              <label htmlFor="password" className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full rounded-xl border border-cam-500/20 bg-white/[0.03] px-4 py-3 pr-11 text-white placeholder-slate-600 transition-colors duration-200 focus:border-cam-400 focus:outline-none"
                  placeholder="Enter password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-cam-400"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? (
                    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5"><path d="M3 3L21 21M10.6 10.6C10.2 11 10 11.5 10 12C10 13.1 10.9 14 12 14C12.5 14 13 13.8 13.4 13.4M6.5 6.7C4.5 8 3 10 2 12C4 16.5 8 19 12 19C13.8 19 15.5 18.5 17 17.6M9.5 5.2C10.3 5 11.1 5 12 5C16 5 20 7.5 22 12C21.5 13.1 20.9 14.1 20.1 15" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5"><path d="M2 12C4 7.5 8 5 12 5C16 5 20 7.5 22 12C20 16.5 16 19 12 19C8 19 4 16.5 2 12Z" stroke="currentColor" strokeWidth="1.6" /><circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.6" /></svg>
                  )}
                </button>
              </div>
            </div>

            {error && (
              <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-sm text-red-400">
                {error}
              </div>
            )}

            <button type="submit" disabled={submitting} className="glow-btn w-full disabled:opacity-60">
              {submitting ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="mt-6 text-center text-xs text-slate-600">
          <NavLink to="/" className="hover:text-cam-400">← Back to Cam Launcher</NavLink>
        </p>
      </div>
    </div>
  )
}
