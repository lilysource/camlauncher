import { useEffect, useState } from 'react'
import { getChangelog, saveChangelog } from '../../data/changelog.js'

const emptyForm = { version: '', date: '', itemsText: '' }

export default function ManageChangelog() {
  const [entries, setEntries] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    setEntries(getChangelog())
  }, [])

  const persist = (next) => {
    setEntries(next)
    saveChangelog(next)
  }

  const openAddForm = () => {
    setForm(emptyForm)
    setEditingId(null)
    setShowForm(true)
  }

  const openEditForm = (entry) => {
    setForm({ version: entry.version, date: entry.date, itemsText: entry.items.join('\n') })
    setEditingId(entry.id)
    setShowForm(true)
  }

  const handleDelete = (id) => {
    if (!confirm('Delete this changelog entry? This cannot be undone.')) return
    persist(entries.filter((e) => e.id !== id))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const items = form.itemsText.split('\n').map((s) => s.trim()).filter(Boolean)
    if (!form.version || !form.date || items.length === 0) return

    let next
    if (editingId) {
      next = entries.map((entry) =>
        entry.id === editingId ? { id: editingId, version: form.version, date: form.date, items } : entry
      )
    } else {
      next = [{ id: `c${Date.now()}`, version: form.version, date: form.date, items }, ...entries]
    }

    persist(next)
    setShowForm(false)
    setForm(emptyForm)
    setEditingId(null)
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="eyebrow">Changelog</span>
          <h1 className="mt-2 font-display text-3xl font-bold text-white">Manage Changelog</h1>
        </div>
        <button onClick={openAddForm} className="glow-btn !px-5 !py-2.5 !text-sm">
          <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4">
            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          Add Entry
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card mt-6 space-y-4 p-6 animate-fade-up">
          <h2 className="font-display text-lg font-bold text-white">
            {editingId ? 'Edit Entry' : 'Add New Entry'}
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">Version</label>
              <input
                required
                value={form.version}
                onChange={(e) => setForm({ ...form, version: e.target.value })}
                placeholder="e.g. 2.1"
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white placeholder-slate-600 focus:border-cam-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">Date</label>
              <input
                required
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white focus:border-cam-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
              Changes (one per line)
            </label>
            <textarea
              required
              rows={4}
              value={form.itemsText}
              onChange={(e) => setForm({ ...form, itemsText: e.target.value })}
              placeholder={'New UI\nBetter performance\nBug fixes'}
              className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white placeholder-slate-600 focus:border-cam-400 focus:outline-none"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button type="submit" className="glow-btn !px-5 !py-2.5 !text-sm">
              {editingId ? 'Save Changes' : 'Add Entry'}
            </button>
            <button
              type="button"
              onClick={() => { setShowForm(false); setEditingId(null) }}
              className="glow-btn-outline !px-5 !py-2.5 !text-sm"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6 flex flex-col gap-4">
        {entries.map((entry) => (
          <div key={entry.id} className="glass-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-base font-bold text-white">Version {entry.version}</h3>
                <p className="text-xs text-slate-500">{entry.date}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEditForm(entry)} className="rounded-lg border border-cam-500/20 px-3.5 py-2 font-display text-xs font-semibold text-cam-400 transition-colors hover:bg-cam-500/10">
                  Edit
                </button>
                <button onClick={() => handleDelete(entry.id)} className="rounded-lg border border-red-500/20 px-3.5 py-2 font-display text-xs font-semibold text-red-400 transition-colors hover:bg-red-500/10">
                  Delete
                </button>
              </div>
            </div>
            <ul className="mt-3 space-y-1.5 text-sm text-slate-400">
              {entry.items.map((item, idx) => (
                <li key={idx}>• {item}</li>
              ))}
            </ul>
          </div>
        ))}
        {entries.length === 0 && (
          <div className="glass-card p-10 text-center text-slate-400">No changelog entries yet. Add one above.</div>
        )}
      </div>
    </div>
  )
}
