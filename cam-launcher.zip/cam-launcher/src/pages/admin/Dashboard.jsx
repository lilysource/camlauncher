import { useMemo } from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'
import { getDownloads } from '../../data/downloads.js'
import { getChangelog } from '../../data/changelog.js'

export default function Dashboard() {
  const { user } = useAuth()
  const downloads = useMemo(() => getDownloads(), [])
  const changelog = useMemo(() => getChangelog(), [])
  const latest = downloads.find((d) => d.isLatest)

  const stats = [
    { label: 'Total Versions', value: downloads.length },
    { label: 'Changelog Entries', value: changelog.length },
    { label: 'Latest Version', value: latest ? `v${latest.version}` : '—' },
  ]

  return (
    <div>
      <div className="animate-fade-up">
        <span className="eyebrow">Admin Panel</span>
        <h1 className="mt-2 font-display text-3xl font-bold text-white">
          Welcome back, {user?.username}
        </h1>
        <p className="mt-1.5 text-slate-400">Here's what's happening with Cam Launcher.</p>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-3">
        {stats.map((s, i) => (
          <div key={s.label} className="glass-card animate-fade-up p-6" style={{ animationDelay: `${i * 60}ms` }}>
            <p className="eyebrow">{s.label}</p>
            <p className="mt-2 font-display text-3xl font-bold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <NavLink to="/admin/downloads" className="glass-card group flex items-center justify-between p-6 transition-all duration-300 hover:border-cam-500/40">
          <div>
            <h3 className="font-display text-lg font-bold text-white">Manage Downloads</h3>
            <p className="mt-1 text-sm text-slate-400">Add, edit, or remove launcher versions.</p>
          </div>
          <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-cam-400 transition-transform duration-300 group-hover:translate-x-1">
            <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </NavLink>

        <NavLink to="/admin/changelog" className="glass-card group flex items-center justify-between p-6 transition-all duration-300 hover:border-cam-500/40">
          <div>
            <h3 className="font-display text-lg font-bold text-white">Manage Changelog</h3>
            <p className="mt-1 text-sm text-slate-400">Add, edit, or remove update entries.</p>
          </div>
          <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-cam-400 transition-transform duration-300 group-hover:translate-x-1">
            <path d="M5 12H19M19 12L13 6M19 12L13 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </NavLink>
      </div>
    </div>
  )
}
