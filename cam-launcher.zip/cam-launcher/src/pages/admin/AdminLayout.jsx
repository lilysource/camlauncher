import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'

const navItems = [
  {
    to: '/admin',
    label: 'Dashboard',
    end: true,
    icon: <path d="M4 13H10V4H4V13ZM4 20H10V15H4V20ZM12 20H20V11H12V20ZM12 4V9H20V4H12Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />,
  },
  {
    to: '/admin/downloads',
    label: 'Manage Downloads',
    icon: <path d="M12 3V15M12 15L7 10M12 15L17 10M4 17V19C4 20.1 4.9 21 6 21H18C19.1 21 20 20.1 20 19V17" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />,
  },
  {
    to: '/admin/changelog',
    label: 'Manage Changelog',
    icon: <path d="M4 6H20M4 12H20M4 18H14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />,
  },
  {
    to: '/admin/settings',
    label: 'Settings',
    icon: (
      <>
        <path d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" strokeWidth="1.6" />
        <path d="M19 12C19 12.3 19 12.6 18.96 12.9L21 14.5L19.5 17.1L17.1 16.2C16.6 16.6 16.05 16.95 15.45 17.2L15.1 19.7H12.3L11.95 17.2C11.35 16.95 10.8 16.6 10.3 16.2L7.9 17.1L6.4 14.5L8.44 12.9C8.4 12.6 8.4 12.3 8.4 12C8.4 11.7 8.4 11.4 8.44 11.1L6.4 9.5L7.9 6.9L10.3 7.8C10.8 7.4 11.35 7.05 11.95 6.8L12.3 4.3H15.1L15.45 6.8C16.05 7.05 16.6 7.4 17.1 7.8L19.5 6.9L21 9.5L18.96 11.1C19 11.4 19 11.7 19 12Z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
      </>
    ),
  },
]

export default function AdminLayout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login', { replace: true })
  }

  return (
    <div className="flex min-h-screen bg-void-950">
      {/* Mobile top bar */}
      <div className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b border-cam-500/15 bg-void-950/90 px-5 py-4 backdrop-blur-xl md:hidden">
        <span className="font-display text-lg font-bold text-white">Admin Panel</span>
        <button onClick={() => setSidebarOpen((s) => !s)} className="text-slate-300" aria-label="Toggle sidebar">
          <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6">
            <path d="M4 7H20M4 12H20M4 17H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-30 w-64 border-r border-cam-500/15 bg-void-900/95 backdrop-blur-xl transition-transform duration-300 md:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col p-5 pt-20 md:pt-6">
          <div className="mb-8 hidden items-center gap-2.5 md:flex">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-cam-500 to-cam-700 shadow-glow">
              <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-white">
                <path d="M5 19L12 4L19 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M8.5 13H15.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </span>
            <div>
              <p className="font-display text-base font-bold text-white leading-tight">Cam Launcher</p>
              <p className="text-xs text-slate-500">Admin Panel</p>
            </div>
          </div>

          <nav className="flex-1 space-y-1.5">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3.5 py-2.5 font-display text-sm font-semibold transition-colors duration-200 ${
                    isActive
                      ? 'bg-cam-500/15 text-cam-400 ring-1 ring-cam-500/25'
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                  }`
                }
              >
                <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 shrink-0">
                  {item.icon}
                </svg>
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="mt-auto border-t border-white/5 pt-4">
            <div className="mb-3 flex items-center gap-2.5 px-1">
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-cam-500/15 font-display text-xs font-bold text-cam-400 ring-1 ring-cam-500/25">
                {user?.username?.[0]?.toUpperCase()}
              </span>
              <span className="truncate text-sm text-slate-300">{user?.username}</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 font-display text-sm font-semibold text-red-400 transition-colors duration-200 hover:bg-red-500/10"
            >
              <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5">
                <path d="M9 21H5C4.4 21 4 20.6 4 20V4C4 3.4 4.4 3 5 3H9M16 17L21 12L16 7M21 12H9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              Logout
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/60 backdrop-blur-sm md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main content */}
      <main className="flex-1 px-5 pb-16 pt-20 md:ml-64 md:pt-10">
        <div className="mx-auto max-w-5xl">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
