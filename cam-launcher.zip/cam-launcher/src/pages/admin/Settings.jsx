import { useState } from 'react'
import { useAuth } from '../../context/AuthContext.jsx'

export default function Settings() {
  const { user } = useAuth()
  const [siteName, setSiteName] = useState('Cam Launcher')
  const [maintenance, setMaintenance] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = (e) => {
    e.preventDefault()
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div>
      <span className="eyebrow">Settings</span>
      <h1 className="mt-2 font-display text-3xl font-bold text-white">Site Settings</h1>
      <p className="mt-1.5 text-slate-400">Manage general configuration for Cam Launcher.</p>

      <form onSubmit={handleSave} className="glass-card mt-6 max-w-xl space-y-6 p-6">
        <div>
          <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
            Site Name
          </label>
          <input
            value={siteName}
            onChange={(e) => setSiteName(e.target.value)}
            className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white focus:border-cam-400 focus:outline-none"
          />
        </div>

        <div>
          <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
            Logged in as
          </label>
          <input
            value={user?.username || ''}
            disabled
            className="w-full cursor-not-allowed rounded-lg border border-cam-500/10 bg-white/[0.02] px-3.5 py-2.5 text-slate-500"
          />
        </div>

        <label className="flex items-center justify-between rounded-lg border border-cam-500/15 bg-white/[0.02] px-4 py-3.5">
          <div>
            <p className="font-display text-sm font-semibold text-white">Maintenance Mode</p>
            <p className="text-xs text-slate-500">Temporarily disable public downloads.</p>
          </div>
          <input
            type="checkbox"
            checked={maintenance}
            onChange={(e) => setMaintenance(e.target.checked)}
            className="h-5 w-9 accent-cam-500"
          />
        </label>

        <div className="flex items-center gap-3">
          <button type="submit" className="glow-btn !px-5 !py-2.5 !text-sm">
            Save Settings
          </button>
          {saved && <span className="text-sm text-emerald-400">Saved successfully.</span>}
        </div>
      </form>
    </div>
  )
}
