import { useEffect, useState } from 'react'
import { getDownloads, saveDownloads } from '../../data/downloads.js'

const emptyForm = { version: '', releaseDate: '', fileSize: '', isLatest: false, url: '#' }

export default function ManageDownloads() {
  const [downloads, setDownloads] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    setDownloads(getDownloads())
  }, [])

  const persist = (next) => {
    setDownloads(next)
    saveDownloads(next)
  }

  const openAddForm = () => {
    setForm(emptyForm)
    setEditingId(null)
    setShowForm(true)
  }

  const openEditForm = (item) => {
    setForm(item)
    setEditingId(item.id)
    setShowForm(true)
  }

  const handleDelete = (id) => {
    if (!confirm('Delete this version? This cannot be undone.')) return
    persist(downloads.filter((d) => d.id !== id))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!form.version || !form.releaseDate || !form.fileSize) return

    let next
    if (editingId) {
      next = downloads.map((d) => (d.id === editingId ? { ...form, id: editingId } : d))
    } else {
      next = [{ ...form, id: `d${Date.now()}` }, ...downloads]
    }

    if (form.isLatest) {
      next = next.map((d) => ({ ...d, isLatest: d.id === (editingId || next[0].id) }))
    }

    persist(next)
    setShowForm(false)
    setForm(emptyForm)
    setEditingId(null)
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="eyebrow">Downloads</span>
          <h1 className="mt-2 font-display text-3xl font-bold text-white">Manage Downloads</h1>
        </div>
        <button onClick={openAddForm} className="glow-btn !px-5 !py-2.5 !text-sm">
          <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4">
            <path d="M12 5V19M5 12H19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          Add Version
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card mt-6 space-y-4 p-6 animate-fade-up">
          <h2 className="font-display text-lg font-bold text-white">
            {editingId ? 'Edit Version' : 'Add New Version'}
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">Version</label>
              <input
                required
                value={form.version}
                onChange={(e) => setForm({ ...form, version: e.target.value })}
                placeholder="e.g. 2.1.0"
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white placeholder-slate-600 focus:border-cam-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">Release Date</label>
              <input
                required
                type="date"
                value={form.releaseDate}
                onChange={(e) => setForm({ ...form, releaseDate: e.target.value })}
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white focus:border-cam-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">File Size</label>
              <input
                required
                value={form.fileSize}
                onChange={(e) => setForm({ ...form, fileSize: e.target.value })}
                placeholder="e.g. 48.2 MB"
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white placeholder-slate-600 focus:border-cam-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block font-display text-xs font-semibold uppercase tracking-wider text-slate-400">Download URL</label>
              <input
                value={form.url}
                onChange={(e) => setForm({ ...form, url: e.target.value })}
                placeholder="#"
                className="w-full rounded-lg border border-cam-500/20 bg-white/[0.03] px-3.5 py-2.5 text-white placeholder-slate-600 focus:border-cam-400 focus:outline-none"
              />
            </div>
          </div>

          <label className="flex items-center gap-2.5 text-sm text-slate-300">
            <input
              type="checkbox"
              checked={form.isLatest}
              onChange={(e) => setForm({ ...form, isLatest: e.target.checked })}
              className="h-4 w-4 rounded border-cam-500/30 bg-white/5 accent-cam-500"
            />
            Mark as latest version
          </label>

          <div className="flex gap-3 pt-2">
            <button type="submit" className="glow-btn !px-5 !py-2.5 !text-sm">
              {editingId ? 'Save Changes' : 'Add Version'}
            </button>
            <button
              type="button"
              onClick={() => { setShowForm(false); setEditingId(null) }}
              className="glow-btn-outline !px-5 !py-2.5 !text-sm"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="mt-6 flex flex-col gap-4">
        {downloads.map((d) => (
          <div key={d.id} className="glass-card flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display text-base font-bold text-white">v{d.version}</h3>
                {d.isLatest && (
                  <span className="rounded-full bg-cam-500/15 px-2 py-0.5 font-display text-[10px] font-bold uppercase tracking-wider text-cam-400 ring-1 ring-cam-500/30">
                    Latest
                  </span>
                )}
              </div>
              <p className="mt-1 text-sm text-slate-400">{d.releaseDate} · {d.fileSize}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => openEditForm(d)} className="rounded-lg border border-cam-500/20 px-3.5 py-2 font-display text-xs font-semibold text-cam-400 transition-colors hover:bg-cam-500/10">
                Edit
              </button>
              <button onClick={() => handleDelete(d.id)} className="rounded-lg border border-red-500/20 px-3.5 py-2 font-display text-xs font-semibold text-red-400 transition-colors hover:bg-red-500/10">
                Delete
              </button>
            </div>
          </div>
        ))}
        {downloads.length === 0 && (
          <div className="glass-card p-10 text-center text-slate-400">No versions yet. Add one above.</div>
        )}
      </div>
    </div>
  )
}
