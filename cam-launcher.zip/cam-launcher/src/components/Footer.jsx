import { NavLink } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="relative border-t border-cam-500/10 bg-void-900/60">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cam-500 to-cam-700 shadow-glow">
                <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4 text-white">
                  <path d="M5 19L12 4L19 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M8.5 13H15.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </span>
              <span className="font-display text-lg font-bold text-white">Cam Launcher</span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-slate-400">
              Fast, secure, and easy launcher — built for players who don't want to wait.
            </p>
          </div>

          <div>
            <h4 className="eyebrow mb-4">Navigate</h4>
            <ul className="space-y-2.5 text-sm">
              <li><NavLink to="/" className="text-slate-400 transition-colors hover:text-cam-400">Home</NavLink></li>
              <li><NavLink to="/download" className="text-slate-400 transition-colors hover:text-cam-400">Download</NavLink></li>
              <li><NavLink to="/changelog" className="text-slate-400 transition-colors hover:text-cam-400">Changelog</NavLink></li>
            </ul>
          </div>

          <div>
            <h4 className="eyebrow mb-4">Status</h4>
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              All systems operational
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-xs text-slate-500 md:flex-row">
          <p>© {new Date().getFullYear()} Cam Launcher. All rights reserved.</p>
          <p>Built for speed. Built for players.</p>
        </div>
      </div>
    </footer>
  )
}
