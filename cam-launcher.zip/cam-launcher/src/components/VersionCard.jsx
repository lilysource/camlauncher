export default function VersionCard({ version, releaseDate, fileSize, isLatest, url = '#' }) {
  const formattedDate = new Date(releaseDate).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  return (
    <div className="glass-card group flex flex-col gap-5 p-6 transition-all duration-300 hover:border-cam-500/40 hover:bg-white/[0.05] sm:flex-row sm:items-center sm:justify-between animate-fade-up">
      <div className="flex items-start gap-4">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-cam-500/10 text-cam-400 ring-1 ring-cam-500/20">
          <svg viewBox="0 0 24 24" fill="none" className="h-6 w-6">
            <rect x="4" y="3" width="16" height="18" rx="2" stroke="currentColor" strokeWidth="1.6" />
            <path d="M8 8H16M8 12H16M8 16H12" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </div>
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-lg font-bold text-white">Version {version}</h3>
            {isLatest && (
              <span className="rounded-full bg-cam-500/15 px-2.5 py-0.5 font-display text-[11px] font-bold uppercase tracking-wider text-cam-400 ring-1 ring-cam-500/30">
                Latest
              </span>
            )}
          </div>
          <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-400">
            <span>Released {formattedDate}</span>
            <span className="text-slate-600">•</span>
            <span>{fileSize}</span>
          </div>
        </div>
      </div>

      <a href={url} className="glow-btn w-full shrink-0 sm:w-auto">
        <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4">
          <path d="M12 3V15M12 15L7 10M12 15L17 10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4 17V19C4 20.1046 4.89543 21 6 21H18C19.1046 21 20 20.1046 20 19V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
        Download
      </a>
    </div>
  )
}
