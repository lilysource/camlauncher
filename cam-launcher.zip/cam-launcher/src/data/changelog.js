const STORAGE_KEY = 'camlauncher_changelog'

const defaultChangelog = [
  {
    id: 'c3',
    version: '2.0',
    date: '2026-06-12',
    items: ['New UI', 'Better performance', 'Bug fixes'],
  },
  {
    id: 'c2',
    version: '1.5',
    date: '2026-02-03',
    items: ['Improved launcher'],
  },
  {
    id: 'c1',
    version: '1.0',
    date: '2025-09-18',
    items: ['Initial release'],
  },
]

export function getChangelog() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch {
    // fall through to defaults
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultChangelog))
  return defaultChangelog
}

export function saveChangelog(changelog) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(changelog))
}
