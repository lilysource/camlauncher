const STORAGE_KEY = 'camlauncher_downloads'

const defaultDownloads = [
  {
    id: 'd3',
    version: '2.0.0',
    releaseDate: '2026-06-12',
    fileSize: '48.2 MB',
    isLatest: true,
    url: '#',
  },
  {
    id: 'd2',
    version: '1.5.2',
    releaseDate: '2026-02-03',
    fileSize: '41.7 MB',
    isLatest: false,
    url: '#',
  },
  {
    id: 'd1',
    version: '1.0.0',
    releaseDate: '2025-09-18',
    fileSize: '36.4 MB',
    isLatest: false,
    url: '#',
  },
]

export function getDownloads() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch {
    // fall through to defaults
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultDownloads))
  return defaultDownloads
}

export function saveDownloads(downloads) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(downloads))
}
