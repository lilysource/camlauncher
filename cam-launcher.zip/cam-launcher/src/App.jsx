import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Download from './pages/Download.jsx'
import Changelog from './pages/Changelog.jsx'
import Login from './pages/Login.jsx'
import NotFound from './pages/NotFound.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import AdminLayout from './pages/admin/AdminLayout.jsx'
import Dashboard from './pages/admin/Dashboard.jsx'
import ManageDownloads from './pages/admin/ManageDownloads.jsx'
import ManageChangelog from './pages/admin/ManageChangelog.jsx'
import Settings from './pages/admin/Settings.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/download" element={<Download />} />
      <Route path="/changelog" element={<Changelog />} />
      <Route path="/login" element={<Login />} />

      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="downloads" element={<ManageDownloads />} />
        <Route path="changelog" element={<ManageChangelog />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
